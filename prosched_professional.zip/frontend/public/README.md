Add your screenshots to the 'screenshots' folder and reference them in README or app.
