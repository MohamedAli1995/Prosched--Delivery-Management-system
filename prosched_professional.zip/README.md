# ProSched - Delivery Management System (Professional starter)

This package contains a professional starter for the ProSched project:
- Backend: Node.js + Express + Mongoose
- Frontend: React (simple demo UI)
- Services: Twilio helper, simple route optimizer
- Ready-to-run instructions in root README

## Quick start

1. Backend:
   - cd backend
   - npm install
   - cp .env.example .env   # edit values (MONGODB_URI, TWILIO keys)
   - npm run dev

2. Frontend:
   - cd frontend
   - npm install
   - add .env with REACT_APP_API_URL=http://localhost:4000/api
   - npm start

